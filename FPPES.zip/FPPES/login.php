<!-- YOU NEED TO LOGIN FIRST DUDE -->
<?php 

header('location: Home.php');
?>