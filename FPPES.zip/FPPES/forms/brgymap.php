<!doctype html>
<html>
  <head>
    <title>Google Maps Tutorial</title>
    <script src="https://cdn.pubnub.com/sdk/javascript/pubnub.4.19.0.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" />
  </head>
  <body>


    <div class="container">
  <h1>BRGY IN NORTH CALOOCAN</h1>
  <div id="map-canvas" style="width:auto;height:500px"></div>
</div>

<script>

window.lat = 14.756205;
window.lng = 121.043763;

 var beaches = [
        ['Bondi Beach', -33.890542, 151.274856, 4],
        ['Coogee Beach', -33.923036, 151.259052, 5],
        ['Cronulla Beach', -34.028249, 151.157507, 3],
        ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
        ['Maroubra Beach', -33.950198, 151.259302, 1]
      ];

function circlePoint(time) {
  var radius = 0.02;
  var x = Math.cos(time) * radius;
  var y = Math.sin(time) * radius;
  return {lat:window.lat + y, lng:window.lng + x};
};

var map;
var mark;
var initialize = function() {
  map  = new google.maps.Map(document.getElementById('map-canvas'), {center:{lat:lat,lng:lng},zoom:14});
  mark = new google.maps.Marker({position:{lat:lat, lng:lng}, map:map});
};
window.initialize = initialize;

var redraw = function(payload) {
  lat = payload.message.lat;
  lng = payload.message.lng;
  map.setCenter({lat:lat, lng:lng, alt:0});
  mark.setPosition({lat:lat, lng:lng, alt:0});
};

var pnChannel = "map-channel";
var pubnub = new PubNub({
  publishKey:   'pub-c-aebedd22-5539-4886-8abf-194b9eb61201',
  subscribeKey: 'sub-c-6e18550e-2e44-11e8-8cd2-7e0f643babd7'
});

pubnub.subscribe({channels: [pnChannel]});
pubnub.addListener({message:redraw});

//setInterval(function() {
  //pubnub.publish({channel:pnChannel, message:circlePoint(new Date().getTime()/1000)});
//}, 500);
</script>


 <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyDTC8h1SaprocJsR01DYcRoRWa1bVwLEuY
&callback=initialize"></script>

</body>
</html>
