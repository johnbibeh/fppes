<div class="page-head">
          <h2 class="page-head-title"><?= $title?></h2>
          <ol class="breadcrumb page-head-nav">
            <li><a href="/WAZE">Home</a></li>
            <li class="active"><a href="#"><?= $title?></a></li>
          </ol>
        </div>  