<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="/FPPES/assets/img/logo-fav.png">
    <title>PES | Feeding Program</title>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/perfect-scrollbar/css/perfect-scrollbar.min.css"/>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/material-design-icons/css/material-design-iconic-font.min.css"/>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css"/>
    
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/datetimepicker/css/bootstrap-datetimepicker.min.css"/>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/daterangepicker/css/daterangepicker.css"/>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/datatables/css/dataTables.bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/jquery.gritter/css/jquery.gritter.css"/>
    <link href="/FPPES/assets/lib/pines-notify/pnotify.css" type="text/css" rel="stylesheet" media="all"> 
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/bootstrap-multiselect/css/bootstrap-multiselect.css"/>
    <link rel="stylesheet" type="text/css" href="/FPPES/assets/lib/multiselect/css/multi-select.css"/>
    <link rel="stylesheet" href="/FPPES/assets/css/style.css" type="text/css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jcarousel/0.3.9/jquery.jcarousel.min.js"></script>
    <style type="text/css">
        
       *{
        font-family: Century Gothic;
       }

       .sidebar-elements .active {
        background-color: #f0f0f0;
       }
    </style>
</head>