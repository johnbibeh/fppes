<?php
require 'forms/php/app.php';
unset($_SESSION["b80bb7740288fda1f201890375a60c8f"]); 
unset($_SESSION["4040592cec1880aa70936989f05e7c31"]); 
header('Location: /FPPES/login.php');